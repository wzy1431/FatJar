package com.wzy.demo.act;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.wzy.demo.R;

import java.util.HashMap;
import java.util.Map;

import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Response;

/**
 * Copyright @date 2017-02-28 10:30 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public class DemoActivity extends Activity implements View.OnClickListener{


    Button button1;
    Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.demo);
        ButterKnife.bind(this);
        button1 = (Button)findViewById(R.id.button1);
        button2 = (Button)findViewById(R.id.button2);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button1:

                Intent intent = new Intent(getApplicationContext(),RecyclerviewActivity.class);
                startActivity(intent);

                break;
            case R.id.button2:
//                postJson();
//                postMap();
                MvpActivity.start(DemoActivity.this);
                break;
        }
    }
    /*
    * get请求
    * */
    private void getMap(){
        OkGo.get("https://wx.vpiaobao.com/invoicepal/kpb/user/list_user")
                .tag(this)
                .headers("Content-Type", "application/x-www-form-urlencoded")
                .params("access_token", "YWQ4ZGFlNjllNTJmNDFiNTg4YWMzZjY2ZmZiYWE2ZWQ%3D")
                .params("pagenumber", "MQ%3D%3D")
                .params("pagesize", "NTA%3D")
                .params("sig", "f48a39e806a5b853804dd9fa32792209")
                .execute(new StringCallback() {
                    @Override
                    public void onSuccess(String s, Call call, Response response) {
                        System.out.println(""+s);
                        Toast.makeText(DemoActivity.this, s, Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(Call call, Response response, Exception e) {
                        super.onError(call, response, e);
                        Toast.makeText(DemoActivity.this, response.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
    /*
    * post表单
    * */
    private void postMap(){
        Map<String,String> maps = new HashMap<>();
//        maps.put("access_token","YWQ4ZGFlNjllNTJmNDFiNTg4YWMzZjY2ZmZiYWE2ZWQ");
//        maps.put("pagenumber","MQ%3D%3D");
//        maps.put("pagesize","NTA%3D");
//        maps.put("sig","f48a39e806a5b853804dd9fa32792209");
        OkGo.post("https://wx.vpiaobao.com/invoicepal/kpb/user/list_user")
                .tag(this)
                .headers("Content-Type", "application/x-www-form-urlencoded")
//                .params("access_token", "YWQ4ZGFlNjllNTJmNDFiNTg4YWMzZjY2ZmZiYWE2ZWQ%3D")
//                .params("pagenumber", "MQ%3D%3D")
//                .params("pagesize", "NTA%3D")
//                .params("sig", "f48a39e806a5b853804dd9fa32792209")
                .upJson("{\n" +
                        "\t\"access_token\": \"YWQ4ZGFlNjllNTJmNDFiNTg4YWMzZjY2ZmZiYWE2ZWQ%3D\",\n" +
                        "\t\"pagenumber\": \"MQ%3D%3D\",\n" +
                        "\t\"pagesize\": \"NTA%3D\",\n" +
                        "\t\"sig\": \"f48a39e806a5b853804dd9fa32792209\",\n" +
                        "}")
                .isMultipart(true)
                .execute(new StringCallback() {
                    @Override
                    public void onSuccess(String s, Call call, Response response) {
                        System.out.println(""+s);
                        Toast.makeText(DemoActivity.this, s, Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(Call call, Response response, Exception e) {
                        super.onError(call, response, e);
                        Toast.makeText(DemoActivity.this, response.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }


        /*
        * 发送json
        * */
    private void postJson(){
        OkGo.post("http://124.205.208.202/makeInvoiceApp/login")
                .tag(this)
                .upJson("{\n" +
                        "\t\"companyCode\": \"500102201606325\",\n" +
                        "\t\"deviceToken\": \"{\\\"mac\\\":\\\"ec:1d:7f:c3:b7:85\\\",\\\"device_id\\\":\\\"Unknown\\\"}\",\n" +
                        "\t\"deviceType\": \"2\",\n" +
                        "\t\"machineCode\": \"0\",\n" +
                        "\t\"userName\": \"wzy\",\n" +
                        "\t\"userPass\": \"343b1c4a3ea721b2d640fc8700db0f36\"\n" +
                        "}")
                .execute(new StringCallback() {
                    @Override
                    public void onSuccess(String s, Call call, Response response) {
                        System.out.println(""+s);
                        Toast.makeText(DemoActivity.this, s, Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(Call call, Response response, Exception e) {
                        super.onError(call, response, e);
                        Toast.makeText(DemoActivity.this, response.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}

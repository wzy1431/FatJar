package com.wzy.demo.act;

import android.app.Activity;
import android.os.Bundle;

import com.wzy.demo.presenter.BasePresenter;

/**
 * Copyright @date 2017-03-17 16:54 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public abstract class BaseActivity<V,T extends BasePresenter<V>> extends Activity {

    protected T mPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //创建presenter
        mPresenter = createPresenter();
        //绑定VIew
        mPresenter.attachView((V) this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //解除绑定
        mPresenter.detachView();
    }

    //创建Presenter
    protected abstract T createPresenter();


}

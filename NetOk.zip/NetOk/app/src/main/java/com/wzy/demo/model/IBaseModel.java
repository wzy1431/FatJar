package com.wzy.demo.model;

import android.app.Activity;
import android.content.Context;

import com.wzy.demo.bean.LoginBean;

/**
 * model 接口
 */
public interface IBaseModel {
    /**
     * 加载数据
     */
    <T> void load(T t, LoadOnListener<T> listener);



    /**
     * 回调监听，数据接收完成
     */
    interface LoadOnListener<T> {
        //数据传递过来
        void onComplete(T t);
    }

}

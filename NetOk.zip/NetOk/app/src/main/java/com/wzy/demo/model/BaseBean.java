package com.wzy.demo.model;

import java.io.Serializable;

/**
 * Copyright @date 2017-02-22 13:45 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public class BaseBean<T> implements Serializable {

    public int code;
    public String message;
    protected T data;

    private String userId;
    private String userMobile;
    private String companyId;
    private String accessToken;
    private String userName;
    private String userType;
    private String userPic;


    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUserPic() {
        return userPic;
    }

    public void setUserPic(String userPic) {
        this.userPic = userPic;
    }
}

package com.wzy.demo.bean;

/**
 * Copyright @date 2017-03-17 16:48 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public class LoginBean {

    String userId;
    String userMobile;
    String userPass;
    String nickName;
    String registDate;
    String userPic;
    String accessToken;
    String deviceType;
    String deviceToken;
    String companyId;
    String companyCode;
    String machineCode;
    String userType;
    String userName;
    String endDate;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserPass() {
        return userPass;
    }

    public void setUserPass(String userPass) {
        this.userPass = userPass;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getRegistDate() {
        return registDate;
    }

    public void setRegistDate(String registDate) {
        this.registDate = registDate;
    }

    public String getUserPic() {
        return userPic;
    }

    public void setUserPic(String userPic) {
        this.userPic = userPic;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getMachineCode() {
        return machineCode;
    }

    public void setMachineCode(String machineCode) {
        this.machineCode = machineCode;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return "LoginBean{" +
                "userId='" + userId + '\'' +
                ", userMobile='" + userMobile + '\'' +
                ", userPass='" + userPass + '\'' +
                ", nickName='" + nickName + '\'' +
                ", registDate='" + registDate + '\'' +
                ", userPic='" + userPic + '\'' +
                ", accessToken='" + accessToken + '\'' +
                ", deviceType='" + deviceType + '\'' +
                ", deviceToken='" + deviceToken + '\'' +
                ", companyId='" + companyId + '\'' +
                ", companyCode='" + companyCode + '\'' +
                ", machineCode='" + machineCode + '\'' +
                ", userType='" + userType + '\'' +
                ", userName='" + userName + '\'' +
                ", endDate='" + endDate + '\'' +
                '}';
    }
}

package com.wzy.demo;

import android.app.Application;

import com.lzy.okgo.OkGo;

import java.io.IOException;

/**
 * Copyright @date 2017-02-06 15:49 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public class NetOkApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        OkGo.init(this);
        try {
            OkGo.getInstance().setCertificates(getAssets().open("server.crt"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

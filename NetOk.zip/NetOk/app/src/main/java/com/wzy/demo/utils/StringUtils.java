package com.wzy.demo.utils;


import com.wzy.demo.URLs;
import com.wzy.library.Base64;
import com.wzy.library.Md5Util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Copyright @date 2017-02-22 17:03 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public class StringUtils {

    /**
     * 对Map值进行base64转码，并且升序排序 ，然后拼接参数返回拼接后的字符串
     *
     * @param map
     * @return
     */
    public static String convertMapKeyValue(Map<String, String> map) {
        String str = "";
        List<Map.Entry<String, String>> list = new ArrayList<Map.Entry<String, String>>(
                map.entrySet());
        // 然后通过比较器来实现排序
        Collections.sort(list, new Comparator<Map.Entry<String, String>>() {
            // 升序排序
            public int compare(Map.Entry<String, String> o1,
                               Map.Entry<String, String> o2) {
                return o1.getKey().compareTo(o2.getKey());
            }
        });

        for (Map.Entry<String, String> mapping : list) {
            String value = mapping.getValue();
            try {
                value = Base64.encode(value.getBytes("UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            map.put(mapping.getKey(), value);
            str += mapping.getKey() + value;
        }
        str = Md5Util.getMD5Str(str)+ URLs.CLIENT_SECRET;
        return str;
    }
}

package com.wzy.demo.act;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.wzy.demo.bean.LoginBean;
import com.wzy.demo.presenter.BasePresenter;
import com.wzy.demo.presenter.LoginPresenter;
import com.wzy.demo.view.BaseView;
import com.wzy.library.Md5Util;

import java.util.List;

/**
 * Copyright @date 2017-03-17 16:45 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public class MvpActivity extends BaseActivity<BaseView<LoginBean>,LoginPresenter> implements BaseView<LoginBean> {


    public static void start(Context context){
        Intent intent = new Intent(context,MvpActivity.class);
        context.startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LoginBean loginBean = new LoginBean();
        loginBean.setUserName("b");
        loginBean.setUserPass(Md5Util.getMD5Str("777777"));
        loginBean.setCompanyCode("500102201606325");
        loginBean.setMachineCode("0");
        loginBean.setDeviceToken("aaaaaaaa");
        loginBean.setDeviceType("2");
        mPresenter.request(loginBean);

    }

    /**
     * 显示数据
     *
     * @param loginBeen
     */
    @Override
    public void showData(LoginBean loginBeen) {

    }

    /***
     * 显示进度
     */
    @Override
    public void showLoading() {

    }

    /**
     * 隐藏进度
     */
    @Override
    public void hideLoading() {

    }

    @Override
    protected LoginPresenter createPresenter() {
        return new LoginPresenter();
    }
}

package com.wzy.demo.model;

import java.io.Serializable;

/**
 * Copyright @date 2017-02-22 13:50 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public class UserBean implements Serializable {

//    private String company_code;
//    private String user_name;
//    private String user_pass;
//    private String machine_code;
//    private String device_token;
//    private String client_type;
//    private String sig;
//
//    public String getCompany_code() {
//        return company_code;
//    }
//
//    public void setCompany_code(String company_code) {
//        this.company_code = company_code;
//    }
//
//    public String getUser_name() {
//        return user_name;
//    }
//
//    public void setUser_name(String user_name) {
//        this.user_name = user_name;
//    }
//
//    public String getUser_pass() {
//        return user_pass;
//    }
//
//    public void setUser_pass(String user_pass) {
//        this.user_pass = user_pass;
//    }
//
//    public String getMachine_code() {
//        return machine_code;
//    }
//
//    public void setMachine_code(String machine_code) {
//        this.machine_code = machine_code;
//    }
//
//    public String getDevice_token() {
//        return device_token;
//    }
//
//    public void setDevice_token(String device_token) {
//        this.device_token = device_token;
//    }
//
//    public String getClient_type() {
//        return client_type;
//    }
//
//    public void setClient_type(String client_type) {
//        this.client_type = client_type;
//    }
//
//    public String getSig() {
//        return sig;
//    }
//
//    public void setSig(String sig) {
//        this.sig = sig;
//    }


    private String user_id;
    private String user_mobile;
    private String company_id;
    private String access_token;
    private String user_name;
    private String user_type;
    private String user_pic;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_mobile() {
        return user_mobile;
    }

    public void setUser_mobile(String user_mobile) {
        this.user_mobile = user_mobile;
    }

    public String getCompany_id() {
        return company_id;
    }

    public void setCompany_id(String company_id) {
        this.company_id = company_id;
    }

    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }

    public String getUser_pic() {
        return user_pic;
    }

    public void setUser_pic(String user_pic) {
        this.user_pic = user_pic;
    }
}

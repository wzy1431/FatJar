package com.wzy.demo;

/**
 * Copyright @date 2017-02-23 10:36 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public class URLs {

//    public final static String HOST = "http://10.1.22.218:8080";
    public final static String HOST = "http://wx.vpiaobao.com/invoicepal";
    private final static String URL_SPLITTER = "/";
    private final static String BASEURL = HOST + URL_SPLITTER;
    // 登录
    public static final String LOGIN = BASEURL + "user/login";
    // 注册
    public static final String ADDADMINUSER = "http://10.1.22.218:8080/user/addAdminUser";
    public static final String CLIENT_SECRET = "3S5D3KHDS";
}

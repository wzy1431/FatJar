package com.wzy.demo.presenter;

import android.app.Activity;

import com.wzy.demo.bean.LoginBean;
import com.wzy.demo.model.IBaseModel;
import com.wzy.demo.model.LoginModelImpl;
import com.wzy.demo.view.BaseView;

import java.util.List;

/**
 * Copyright @date 2017-03-17 17:02 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public class LoginPresenter extends BasePresenter<BaseView<LoginBean>>{

    IBaseModel iBaseModel = new LoginModelImpl();

    public void request(LoginBean loginBean){

        //显示进度
        getView().showLoading();
        iBaseModel.load(loginBean, new IBaseModel.LoadOnListener<LoginBean>() {
            @Override
            public void onComplete(LoginBean loginBeen) {
                //显示数据
                getView().showData(loginBeen);
                //隐藏进度
                getView().hideLoading();
            }
        });

    }

}

package com.wzy.demo.act;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.wzy.demo.R;
import com.wzy.demo.adapter.DividerItemDecoration;
import com.wzy.demo.adapter.MyAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Copyright @date 2017-02-28 10:35 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public class RecyclerviewActivity extends Activity {

    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recyclerview);

        mRecyclerView = (RecyclerView)findViewById(R.id.mRecyclerView);

        List<String> list = new ArrayList<String>();
        for (int i = 0; i < 100; i++) {
            list.add("item  "+ i);
        }
        final LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        //设置布局管理器
        mRecyclerView.setLayoutManager(layoutManager);
        MyAdapter adapter = new MyAdapter(list);
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.addItemDecoration(new DividerItemDecoration(RecyclerviewActivity.this,R.drawable.itemdivider));

        mRecyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {

            boolean isShowTop = false;
            boolean isShowBottom = false;

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (layoutManager.findLastCompletelyVisibleItemPosition() == 99) {
                    if (!isShowTop) {
                        Toast.makeText(RecyclerviewActivity.this, "滑动到底部",
                                Toast.LENGTH_SHORT).show();
                    }
                    isShowTop = true;

                } else {
                    isShowTop = false;
                }
                if (layoutManager.findFirstCompletelyVisibleItemPosition() == 0) {
                    if (!isShowBottom) {
                        Toast.makeText(RecyclerviewActivity.this, "滑动到顶部",
                                Toast.LENGTH_SHORT).show();

                    }
                    isShowBottom = true;
                } else {
                    isShowBottom = false;
                }
            }
        });

    }
}

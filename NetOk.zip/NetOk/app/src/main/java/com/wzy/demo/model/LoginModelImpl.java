package com.wzy.demo.model;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.google.gson.Gson;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.request.PostRequest;
import com.wzy.demo.bean.LoginBean;
import com.wzy.demo.callback.DialogCallback;
import com.wzy.demo.callback.JsonCallback;

import okhttp3.Call;
import okhttp3.Response;

/**
 * Copyright @date 2017-03-17 17:06 优识云创（北京）科技有限公司
 * All right reserved.
 *
 * @author wanzhongyi
 * @Description: ${todo}(这里用一句话描述这个类的作用)
 */

public class LoginModelImpl implements IBaseModel{


    /**
     * 加载数据
     *
     * @param t
     * @param listener
     */
    @Override
    public <T> void load( T t, final LoadOnListener<T> listener) {
        String login = JSON.toJSONString(t);
        PostRequest postRequest = OkGo.post("http://124.205.208.202/makeInvoiceApp/login");
        postRequest.upJson(login);
        postRequest.execute(new JsonCallback<LoginBean>() {
            /**
             * 对返回数据进行操作的回调， UI线程
             *
             * @param loginBean
             * @param call
             * @param response
             */
            @Override
            public void onSuccess(LoginBean loginBean, Call call, Response response) {
                System.out.println("===");
                listener.onComplete((T)loginBean);
            }

            @Override
            public void onError(Call call, Response response, Exception e) {
                super.onError(call, response, e);
                System.out.println("===");
            }
        });
    }
}

package com.wzy.demo.model;

import java.io.Serializable;

public class ManagerBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private String id;
	private String user_id; // 用户id

	private String nick_name; // 用户昵称
	private String user_name; // 用户名称

	private String telephone; // 联系方式

	private String user_type; // 用户类型
	private String user_type_desc; // 用户类型描述
	private String end_date;// 截止日期

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getNick_name() {
		return nick_name;
	}

	public void setNick_name(String nick_name) {
		this.nick_name = nick_name;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getUser_type() {
		return user_type;
	}

	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}

	public String getUser_type_desc() {
		return user_type_desc;
	}

	public void setUser_type_desc(String user_type_desc) {
		this.user_type_desc = user_type_desc;
	}

	public static String createManagerBeanTable() {

		StringBuffer managerBeanSql = new StringBuffer();

		managerBeanSql.append("CREATE TABLE IF NOT EXISTS MANAGERBEAN(");
		managerBeanSql.append("  ID INTEGER PRIMARY KEY AUTOINCREMENT,"); // 主键
		managerBeanSql.append("  USER_ID  VARCHAR(32),");
		managerBeanSql.append("  NICK_NAME  VARCHAR(32),");
		managerBeanSql.append("  TELEPHONE  VARCHAR(32),");
		managerBeanSql.append("  USER_TYPE  VARCHAR(32),");
		managerBeanSql.append("  USER_TYPE_DESC  VARCHAR(32)");
		managerBeanSql.append(")");

		return managerBeanSql.toString();

	}

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

}

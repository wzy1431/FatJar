package com.wzy.demo;

import org.junit.Test;

import rx.Observable;
import rx.Observer;
import rx.Subscriber;

import static org.junit.Assert.assertEquals;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);

        Observable<String> observabele = Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                subscriber.onNext("Hello RxJava");
                subscriber.onCompleted();
            }
        });


        Observer<String> observer = new Observer<String>() {
            @Override
            public void onCompleted() {
                System.out.println("-------------------->>>>Completed");
            }

            @Override
            public void onError(Throwable e) {
            }

            @Override
            public void onNext(String s) {
                System.out.println("------------onNext---------->>>>>>>" + s);
            }
        };

        observabele.subscribe(observer);
    }
}
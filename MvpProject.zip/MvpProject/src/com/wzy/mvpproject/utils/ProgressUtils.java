package com.wzy.mvpproject.utils;

import com.wzy.mvpproject.R;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
/**
 * ������
 * @author DELL
 *
 */
public class ProgressUtils {
	
	
	private static ProgressUtils instance;

	/**
	 * ����
	 */
	public static ProgressUtils getProgressUtils() {
		if (instance == null) {
			instance = new ProgressUtils();
		}
		return instance;
	}
	
	/**
	 * ��ʾ���ȿ�ProgressBar
	 */
	public Dialog initProgressDialog(Context context, String msg) {
		LayoutInflater inflater = LayoutInflater.from(context);
		View v = inflater.inflate(R.layout.loading_dialog, null);// �õ�����view
		TextView tipTextView = (TextView) v.findViewById(R.id.tipTextView);// ��ʾ����
		tipTextView.setText(msg);// ���ü�����Ϣ
		Dialog loadingDialog = new Dialog(context, R.style.loading_dialog);// �����Զ�����ʽdialog
		loadingDialog.setCanceledOnTouchOutside(true);
		loadingDialog.setContentView(v, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.MATCH_PARENT));// ���ò���
		return loadingDialog;
	}
	/**
	 * ��ʾ���ȿ�
	 */
	public void showProgressDialog(Dialog pdDialog) {
		if (pdDialog != null && !pdDialog.isShowing()) {
			pdDialog.show();
		}
	}
	/**
	 * ���ؽ��ȿ�
	 */
	public void dissmissProgressDialog(Dialog pdDialog) {
		if (pdDialog != null && pdDialog.isShowing()) {
			pdDialog.dismiss();
			pdDialog = null;
		}
	}

}

package com.wzy.mvpproject.fragment;

import com.wzy.mvpproject.R;
import com.wzy.mvpproject.base.IBaseFragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class SecondFragment extends IBaseFragment {

	private View view;
	
	@Override
	public void init() {
		
	}

	@Override
	public void setcontentView(Bundle savedInstanceState) {
		
	}

	@Override
	public View setcontentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.second, null);
		return view;
	}

	@Override
	public void initView() {
		
	}

	@Override
	public void initData() {
		
	}

	@Override
	public void initListener() {
		
	}
	

}

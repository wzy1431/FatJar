package com.wzy.mvpproject.fragment;

import com.wzy.mvpproject.R;
import com.wzy.mvpproject.activity.NewsListActivity;
import com.wzy.mvpproject.base.IBaseFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

public class FirstFragment extends IBaseFragment implements OnClickListener{

	
	private Button button1;
	private View view;
	
	
	@Override
	public void init() {
		
	}

	@Override
	public void setcontentView(Bundle savedInstanceState) {
		
	}

	@Override
	public View setcontentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.first,  null);
		return view;
	}

	@Override
	public void initView() {
		button1 = $(R.id.button1);
	}


	@Override
	public void initData() {
		
	}

	@Override
	public void initListener() {
		button1.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.button1:
			Intent intent = new Intent(mContext, NewsListActivity.class);
			mContext.startActivity(intent);
			break;
		}
		
	}

}

package com.wzy.mvpproject.module;

import java.util.ArrayList;
import java.util.List;

import com.wzy.mvpproject.bean.News;

import android.os.Handler;

/**
 * Model�ӿ�ʵ����
 * @param <E>
 */
public class NewsModelImpl<T, E> implements INewsModel<T,E> {

	//��������

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void loadGirls(T t,final GirlLoadOnListener listener) {
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				List<News> dataList = new ArrayList<News>();
		        for (int i = 0; i < 111215; i++) {
		            News g = new News();
		            g.setName("MVPģʽ����" + i);
		            g.setContent("MVPģʽ����" + i);
		            dataList.add(g);
		        }
		        listener.onComplete(dataList);
				
			}
		}).start();
		
	}
}

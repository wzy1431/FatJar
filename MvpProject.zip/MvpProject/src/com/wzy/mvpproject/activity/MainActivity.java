package com.wzy.mvpproject.activity;

import com.wzy.mvpproject.R;
import com.wzy.mvpproject.base.IBaseActivity;
import com.wzy.mvpproject.fragment.FirstFragment;
import com.wzy.mvpproject.fragment.SecondFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

public class MainActivity extends IBaseActivity implements OnClickListener{

	private FirstFragment firstFragment;
	private SecondFragment secondFragment;
	private RelativeLayout rl_home, rl_search;
	
	@Override
	public void init() {
		firstFragment = new FirstFragment();
		secondFragment = new SecondFragment();
		
	}

	@Override
	public void setcontentView(Bundle savedInstanceState) {
		setContentView(R.layout.activity_main);
	}

	@Override
	public View setcontentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return null;
	}

	@Override
	public void initView() {
		rl_home = $(R.id.rl_home);
		rl_search = $(R.id.rl_search);
		setCurrentFragment(firstFragment);
		addFragment(firstFragment, R.id.frameLayout, "", 0, 0);
		
	}

	@Override
	public void initData() {
		
	}

	@Override
	public void initListener() {
		rl_home.setOnClickListener(this);
		rl_search.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.rl_home:
			changeFragment(firstFragment, R.id.frameLayout);
			break;
		case R.id.rl_search:
			changeFragment(secondFragment, R.id.frameLayout);
			break;
		}
	}

	
}

package com.wzy.mvpproject.activity;

import java.util.ArrayList;
import java.util.List;

import com.wzy.mvpproject.R;
import com.wzy.mvpproject.adapter.CommonAdapter;
import com.wzy.mvpproject.adapter.ViewHolder;
import com.wzy.mvpproject.bean.News;
import com.wzy.mvpproject.presenter.NewsPresenter;
import com.wzy.mvpproject.utils.ProgressUtils;
import com.wzy.mvpproject.view.BaseView;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

public class NewsListActivity extends BaseActivity<BaseView<List<News>>, NewsPresenter> implements BaseView<List<News>> {

	
	private ListView listview;
	private CommonAdapter<News> commonAdapter;
	private List<News> mNews;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//view �� model��
        mPresenter.fetch();
	}

    @Override
    protected NewsPresenter createPresenter() {
    	return new NewsPresenter();
    	
    }

    @Override
    public void showData(List<News> news) {
    	Log.i("TAG", news+"");
    	mNews = news;
    	Handler handler = new Handler(getMainLooper());
    	handler.post(new Runnable() {
			
			@Override
			public void run() {
				commonAdapter.updateListView(mNews);
			}
		});
    	
    }

    @Override
    public void showLoading() {
        ProgressUtils.getProgressUtils().showProgressDialog(pdDialog);
    }

    @Override
    public void hideLoading() {
    	ProgressUtils.getProgressUtils().dissmissProgressDialog(pdDialog);
    }	

	@Override
	public void init() {
		
	}

	@Override
	public void setcontentView(Bundle savedInstanceState) {
		setContentView(R.layout.listview);
	}

	@Override
	public View setcontentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return null;
	}

	@Override
	public void initView() {
		listview = $(R.id.listView1);
	}

	@Override
	public void initData() {
		mNews = new ArrayList<News>();
		commonAdapter = new CommonAdapter<News>(getApplicationContext(),mNews,R.layout.item) {
			
			@Override
			public void convert(ViewHolder helper, News item) {
				helper.setText(R.id.textView1, item.getName());
				helper.setText(R.id.textView2, item.getContent());
			}
		};
		listview.setAdapter(commonAdapter);
	}

	@Override
	public void initListener() {
		
	}
}

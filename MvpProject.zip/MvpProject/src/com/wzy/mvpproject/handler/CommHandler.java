package com.wzy.mvpproject.handler;

import android.os.Handler;

public class CommHandler extends Handler {

	private static volatile CommHandler handler;
	
	public static CommHandler getInstance(){
		
		if(handler == null){
			handler = new CommHandler();	
		}
		return handler;
	}
	
}

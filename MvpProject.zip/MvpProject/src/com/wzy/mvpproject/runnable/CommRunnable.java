package com.wzy.mvpproject.runnable;

import com.wzy.mvpproject.base.Res;

public class CommRunnable implements Runnable{
	
	private Res data;
	
	public CommRunnable(Res data) {
		super();
		this.data = data;
	}

	@Override
	public void run() {
		
	}

}

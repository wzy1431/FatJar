package com.wzy.mvpproject.base;

import com.wzy.mvpproject.interfaces.WindowsInterface;
import com.wzy.mvpproject.utils.AppManager;
import com.wzy.mvpproject.utils.ProgressUtils;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;

public abstract class IBaseActivity extends FragmentActivity implements WindowsInterface{

	protected Dialog pdDialog;
	private Fragment currentFragment;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		AppManager.getAppManager().addActivity(this);
		pdDialog = ProgressUtils.getProgressUtils().initProgressDialog(this, "");
	
		//��ʼ���������
        init();
        //���ز����ļ�
        setcontentView(savedInstanceState);
        //����view
        initView();
        //�󶨼���
        initListener();
        //��������
        initData();
	
	}
	
	
	/**
     * ����һ�������˱�ʶ��fragment�� �������϶���
     *
     * @param fragment  Ҫ���ӵ�fragment
     * @param layout �滻�Ĳ���ID
     * @param in        ���붯��
     * @param out       �˳�����
     */
    protected void addFragment(Fragment fragment, int layout, String TAG, int in, int out) {
        if (fragment == null) return;
        if (fragment.isVisible()) return;
        if (fragment.isAdded()) return;
        FragmentTransaction ft = getSupportFragmentManager()
                .beginTransaction();
        if (in > 0 && out > 0) {
            ft.setCustomAnimations(in,
                    out);
        }
        if (!TextUtils.isEmpty(TAG)) {
            ft.addToBackStack(TAG);
        }
        ft.add(layout, fragment);
        ft.commitAllowingStateLoss();
    }
	
    /**
     * �滻һ��fragment,����������
     *
     * @param fragment  Ҫ�滻��fragment
     * @param layout �滻�Ĳ���ID
     */
    protected void replaceFragment(Fragment fragment, int layout, int in, int out) {
        if (fragment == null) return;
        if (fragment.isVisible()) return;
        FragmentTransaction ft = getSupportFragmentManager()
                .beginTransaction();
        if (in > 0 && out > 0) {
            ft.setCustomAnimations(in,
                    out);
        }
        ft.replace(layout, fragment);
        ft.commitAllowingStateLoss();
    }


    /**
     * ʹ��ǰ������� setCurrentFragment ���õ�ǰ��fragment
     *
     * @param fragment
     * @param layout
     */
    protected void changeFragment(Fragment fragment, int layout) {
        if (fragment == null || currentFragment == null) return;
        if (fragment == currentFragment) return;
        FragmentTransaction ft = getSupportFragmentManager()
                .beginTransaction();
        if (!fragment.isAdded()) {
            ft.add(layout, fragment);
        }
        ft.hide(currentFragment);
        ft.show(fragment);
        currentFragment = fragment;
        ft.commit();
    }

    /**
     * �����л�fragment���¼��ǰ��fragment
     *
     * @param currentFragment
     */
    public void setCurrentFragment(Fragment currentFragment) {
        this.currentFragment = currentFragment;
    }
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		AppManager.getAppManager().finishActivity(this);
		ProgressUtils.getProgressUtils().dissmissProgressDialog(pdDialog);
	}
	
	/**
	 * findviewByIDͨ�÷���
	 *
	 * @param viewId
	 * @return
	 * @author 
	 */

	@SuppressWarnings("unchecked")
	public <T> T $(int viewId) {
		return (T) findViewById(viewId);
	}
	
}

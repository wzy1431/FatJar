package com.wzy.mvpproject.base;

public abstract class commResponse<T> {
	
	public abstract void updataView(T t);

}

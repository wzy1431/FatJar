package com.wzy.mvpproject.interfaces;

import java.util.ArrayList;

public abstract class Observable<T> {

	
	public final ArrayList<T> observerList = new ArrayList<T>();

    /**
     * ע��۲��߶���
     *
     * @param t
     */
    public void registerObserver(T t) {
        checkNull(t);
        observerList.add(t);
    }

    /**
     * ע���۲��߶���
     *
     * @param t
     */
    public void unRegisterObserver(T t) {
        checkNull(t);
        observerList.remove(t);
    }

    /**
     * �ж������Ĺ۲��߶����Ƿ�Ϊ��
     *
     * @param t
     */
    private void checkNull(T t) {
        if (t == null) {
            throw new NullPointerException();
        }
    }

    /**
     * ֪ͨ�۲���������Ϊ�ı�
     *
     * @param objects
     */
    public abstract void notifyObservers(int id,Object... objects);
}

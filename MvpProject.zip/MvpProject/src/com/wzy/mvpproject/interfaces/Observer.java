package com.wzy.mvpproject.interfaces;

/**
 * 
 * 观察者接口
 *
 */
public interface Observer {
	
	/**
     * 当被观察者发生改变时，观察者进行的行为动作
     * @param objects
     */
    void action(int id,Object... objects);
}
